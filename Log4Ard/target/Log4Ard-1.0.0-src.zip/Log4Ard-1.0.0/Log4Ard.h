#pragma once

#include <Arduino.h>
#include <HardwareSerial.h>
#include <avr/pgmspace.h>
#include "Logger.h"
#include "SerialLogger.h"